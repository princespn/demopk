<?php

namespace App\Http\Controllers\Api\Merchant;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\Withdraw as ApiWithdraw;

class WithdrawController extends Controller{
    use ApiWithdraw;
}

